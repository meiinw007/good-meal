import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const GoodMealApp());

// ---------- Pixel palette ----------
const cream = Color(0xFFFFF8EC);
const ink = Color(0xFF3B3A36);
const orange = Color(0xFFFF7B26);
const mint = Color(0xFFE4F6EA);
const mintDark = Color(0xFF2F7A55);
const sky = Color(0xFFEAF5FD);

// ---------- Ingredients (edit these to match your list) ----------
const Map<String, List<String>> ingredientGroups = {
  'เนื้อสัตว์ / โปรตีน': ['หมูสับ', 'ไข่', 'ปลากระป๋อง', 'ไก่', 'เต้าหู้'],
  'เครื่องปรุง / เครื่องหอม': ['น้ำปลา', 'ซีอิ๊ว', 'กระเทียม', 'พริก', 'น้ำมันหอย'],
  'ผัก': ['คะน้า', 'กะหล่ำปลี', 'มะเขือเทศ', 'ต้นหอม', 'แครอท'],
};

class Menu {
  final String name;
  final List<String> ingredients; // 4 slots, repeats allowed
  final List<String> steps;
  const Menu(this.name, this.ingredients, this.steps);
}

// ---------- Menus (4 ingredients each, every one is used) ----------
const List<Menu> menus = [
  Menu('หมูสับผัดคะน้าไข่ดาว', ['หมูสับ', 'ไข่', 'น้ำปลา', 'คะน้า'], [
    'ตั้งกระทะ ใส่น้ำมันเล็กน้อย ทอดไข่ดาวให้ขอบกรอบ ตักพักไว้',
    'ใส่หมูสับลงผัดจนสุกและเริ่มหอม',
    'ใส่คะน้า ปรุงด้วยน้ำปลา ผัดไฟแรงประมาณ 1-2 นาที',
    'ตักใส่จาน วางไข่ดาวด้านบน เสิร์ฟกับข้าวสวยร้อนๆ',
  ]),
  Menu('ไข่เจียวหมูสับ', ['ไข่', 'หมูสับ', 'น้ำปลา', 'ต้นหอม'], [
    'ตอกไข่ใส่ชาม ใส่หมูสับ ต้นหอมซอย และน้ำปลา ตีให้เข้ากัน',
    'ตั้งน้ำมันให้ร้อนจัด เทไข่ลงไป',
    'ทอดจนฟูและเหลืองทั้งสองด้าน ตักขึ้นเสิร์ฟ',
  ]),
  Menu('ผัดกะหล่ำปลีไข่', ['กะหล่ำปลี', 'ไข่', 'ซีอิ๊ว', 'กระเทียม'], [
    'ทุบกระเทียม ผัดในน้ำมันจนหอม',
    'ใส่กะหล่ำปลีลงผัดจนเริ่มนิ่ม',
    'ตอกไข่ลงไป ปรุงด้วยซีอิ๊ว ผัดให้เข้ากัน',
    'ตักเสิร์ฟทันที',
  ]),
  Menu('ไก่ผัดพริกกระเทียม', ['ไก่', 'กระเทียม', 'พริก', 'น้ำมันหอย'], [
    'โขลกกระเทียมกับพริกพอหยาบ',
    'ผัดในน้ำมันจนหอม ใส่ไก่ผัดจนสุก',
    'ปรุงด้วยน้ำมันหอย ผัดให้เข้ากัน แล้วตักเสิร์ฟ',
  ]),
  Menu('เต้าหู้ซอสมะเขือเทศ', ['เต้าหู้', 'มะเขือเทศ', 'ซีอิ๊ว', 'ต้นหอม'], [
    'หั่นเต้าหู้เป็นชิ้น ทอดจนเหลืองเล็กน้อย',
    'ใส่มะเขือเทศหั่นลงผัดจนยุ่ย',
    'ปรุงด้วยซีอิ๊ว ใส่เต้าหู้กลับลงไปคลุกเบาๆ',
    'โรยต้นหอมก่อนเสิร์ฟ',
  ]),
  Menu('ปลากระป๋องผัดพริก', ['ปลากระป๋อง', 'พริก', 'กระเทียม', 'ต้นหอม'], [
    'ผัดกระเทียมกับพริกให้หอม',
    'ใส่ปลากระป๋อง ผัดให้ปลาแตกพอประมาณ',
    'ชิมรสแล้วตักเสิร์ฟกับข้าวสวย',
  ]),
  Menu('ผัดผักรวมหมูสับ', ['หมูสับ', 'แครอท', 'กะหล่ำปลี', 'น้ำมันหอย'], [
    'ผัดหมูสับจนสุก',
    'ใส่แครอทและกะหล่ำปลี ผัดไฟแรง',
    'ปรุงด้วยน้ำมันหอย ผัดให้เข้ากันแล้วตักเสิร์ฟ',
  ]),
  Menu('ต้มไข่มะเขือเทศ', ['ไข่', 'ไข่', 'มะเขือเทศ', 'น้ำปลา'], [
    'ต้มไข่ 2 ฟอง 8 นาที แล้วปอกเปลือก',
    'ใส่มะเขือเทศลงต้มในน้ำ ปรุงด้วยน้ำปลา',
    'ใส่ไข่ต้มลงไป เคี่ยวต่ออีก 2-3 นาที เสิร์ฟร้อนๆ',
  ]),
];

class GoodMealApp extends StatelessWidget {
  const GoodMealApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Good Meal',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: orange,
          scaffoldBackgroundColor: cream,
          fontFamily: 'monospace',
        ),
        home: const HomePage(),
      );
}

// Pixel-style box: hard border + hard shadow, no rounded corners.
Widget pixelBox(Widget child, {Color color = Colors.white}) => Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color,
        border: Border.all(color: ink, width: 3),
        boxShadow: const [BoxShadow(color: ink, offset: Offset(4, 4))],
      ),
      child: child,
    );

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Set<String> have = {};
  final rng = Random();

  List<Menu> get matches => menus
      .where((m) => m.ingredients.toSet().every(have.contains))
      .toList();

  void openMenu(Menu m) => Navigator.push(
      context, MaterialPageRoute(builder: (_) => MenuPage(menu: m)));

  @override
  Widget build(BuildContext context) {
    final found = matches;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: orange,
        foregroundColor: Colors.white,
        title: const Text('GOOD MEAL',
            style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          pixelBox(
              const Text('เลือกของที่เหลือในตู้เย็น แล้วดูว่าทำเมนูอะไรได้บ้าง',
                  style: TextStyle(fontSize: 14, color: ink)),
              color: sky),
          const SizedBox(height: 16),
          for (final g in ingredientGroups.entries) ...[
            Text(g.key,
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w800, color: ink)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final i in g.value)
                  GestureDetector(
                    onTap: () => setState(
                        () => have.contains(i) ? have.remove(i) : have.add(i)),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: have.contains(i) ? mint : Colors.white,
                        border: Border.all(
                            color: have.contains(i) ? mintDark : ink, width: 3),
                      ),
                      child: Text(
                          have.contains(i) ? '✓ $i' : i,
                          style: TextStyle(
                              color: have.contains(i) ? mintDark : ink,
                              fontWeight: FontWeight.w700)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 16),
          ],
          Row(children: [
            Expanded(
              child: FilledButton(
                style: FilledButton.styleFrom(
                    backgroundColor: orange,
                    shape: const RoundedRectangleBorder()),
                onPressed: () => openMenu(menus[rng.nextInt(menus.length)]),
                child: const Text('สุ่มเมนู'),
              ),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                  foregroundColor: ink, shape: const RoundedRectangleBorder()),
              onPressed: () => setState(have.clear),
              child: const Text('ล้าง'),
            ),
          ]),
          const SizedBox(height: 20),
          Text('ทำได้ ${found.length} เมนู',
              style: const TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w800, color: ink)),
          const SizedBox(height: 8),
          if (have.isEmpty)
            const Text('ยังไม่ได้เลือกวัตถุดิบ', style: TextStyle(color: ink))
          else if (found.isEmpty)
            const Text('ยังไม่มีเมนูที่ใช้ของครบ ลองเพิ่มวัตถุดิบดู',
                style: TextStyle(color: ink)),
          for (final m in found)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: GestureDetector(
                onTap: () => openMenu(m),
                child: pixelBox(Text(m.name,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: ink))),
              ),
            ),
        ],
      ),
    );
  }
}

class MenuPage extends StatelessWidget {
  final Menu menu;
  const MenuPage({super.key, required this.menu});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
            backgroundColor: orange,
            foregroundColor: Colors.white,
            title: Text(menu.name)),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('วัตถุดิบ',
                style: TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w800, color: ink)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final i in menu.ingredients)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                      color: mint,
                      border: Border.all(color: mintDark, width: 3)),
                  child: Text(i,
                      style: const TextStyle(
                          color: mintDark, fontWeight: FontWeight.w700)),
                ),
            ]),
            const SizedBox(height: 20),
            const Text('วิธีทำ',
                style: TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w800, color: ink)),
            const SizedBox(height: 8),
            for (var n = 0; n < menu.steps.length; n++)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: pixelBox(Text('${n + 1}. ${menu.steps[n]}',
                    style: const TextStyle(fontSize: 14, color: ink))),
              ),
          ],
        ),
      );
}
